const fs=require('fs'),path=require('path'),DB=require('better-sqlite3');
fs.mkdirSync(path.join(__dirname,'../data'),{recursive:true});const db=new DB(path.join(__dirname,'../data/vongban.sqlite'));db.pragma('journal_mode=WAL');
db.exec(`
CREATE TABLE IF NOT EXISTS users(id INTEGER PRIMARY KEY,name TEXT NOT NULL,email TEXT UNIQUE NOT NULL,password TEXT NOT NULL,bio TEXT DEFAULT '',city TEXT DEFAULT '',hometown TEXT DEFAULT '',job TEXT DEFAULT '',education TEXT DEFAULT '',birthday TEXT DEFAULT '',avatar TEXT DEFAULT '',cover TEXT DEFAULT '',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS posts(id INTEGER PRIMARY KEY,user_id INTEGER,content TEXT DEFAULT '',media TEXT DEFAULT '',media_type TEXT DEFAULT '',privacy TEXT DEFAULT 'public',created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS follows(follower_id INTEGER,followed_id INTEGER,created_at TEXT DEFAULT CURRENT_TIMESTAMP,PRIMARY KEY(follower_id,followed_id));
CREATE TABLE IF NOT EXISTS likes(user_id INTEGER,post_id INTEGER,PRIMARY KEY(user_id,post_id));
CREATE TABLE IF NOT EXISTS comments(id INTEGER PRIMARY KEY,post_id INTEGER,user_id INTEGER,body TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS messages(id INTEGER PRIMARY KEY,sender_id INTEGER,receiver_id INTEGER,body TEXT,created_at TEXT DEFAULT CURRENT_TIMESTAMP,seen INTEGER DEFAULT 0);
`);module.exports=db;
